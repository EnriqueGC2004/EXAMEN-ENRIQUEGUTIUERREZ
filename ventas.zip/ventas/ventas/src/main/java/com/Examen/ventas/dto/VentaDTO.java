package com.Examen.ventas.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class VentaDTO {

    @NotNull(message = "Sucursal es obligatoria")
    @Size(max = 100, message = "Máximo 100 caracteres")
    private String sucursal;

    @NotNull(message = "La fecha es obligatoria")
    @PastOrPresent(message = "La fecha no puede ser futura")
    private LocalDate fechaVenta;

    @NotNull(message = "Producto es obligatorio")
    @Size(max = 100, message = "Máximo 100 caracteres")
    private String producto;

    @NotNull(message = "Cantidad obligatoria")
    @Min(value = 1, message = "Mínimo 1")
    private Integer cantidad;

    @NotNull(message = "Precio obligatorio")
    @DecimalMin(value = "0.01", message = "Debe ser mayor a cero")
    private BigDecimal precioUnitario;

    // Getters y Setters
    public String getSucursal() { return sucursal; }
    public void setSucursal(String sucursal) { this.sucursal = sucursal; }

    public LocalDate getFechaVenta() { return fechaVenta; }
    public void setFechaVenta(LocalDate fechaVenta) { this.fechaVenta = fechaVenta; }

    public String getProducto() { return producto; }
    public void setProducto(String producto) { this.producto = producto; }

    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }

    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(BigDecimal precioUnitario) { this.precioUnitario = precioUnitario; }
}
