package com.Examen.ventas.service;

import com.Examen.ventas.dto.VentaDTO;
import com.Examen.ventas.entity.Venta;
import java.util.List;

public interface VentaService {
    Venta crearVenta(VentaDTO dto);
    Venta obtenerVenta(Long id);
    List<Venta> listarVentas();
    Venta actualizarVenta(Long id, VentaDTO dto);
    void eliminarVenta(Long id);
}
