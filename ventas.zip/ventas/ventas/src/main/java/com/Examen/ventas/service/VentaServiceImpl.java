package com.Examen.ventas.service;

import com.Examen.ventas.dto.VentaDTO;
import com.Examen.ventas.entity.Venta;
import com.Examen.ventas.repository.VentaRepository;
import com.Examen.ventas.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VentaServiceImpl implements VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    private Venta mapToEntity(VentaDTO dto) {
        Venta venta = new Venta();
        venta.setSucursal(dto.getSucursal());
        venta.setFechaVenta(dto.getFechaVenta());
        venta.setProducto(dto.getProducto());
        venta.setCantidad(dto.getCantidad());
        venta.setPrecioUnitario(dto.getPrecioUnitario());
        return venta;
    }

    @Override
    public Venta crearVenta(VentaDTO dto) {
        return ventaRepository.save(mapToEntity(dto));
    }

    @Override
    public Venta obtenerVenta(Long id) {
        return ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Venta no encontrada con ID: " + id));
    }

    @Override
    public List<Venta> listarVentas() {
        return ventaRepository.findAll();
    }

    @Override
    public Venta actualizarVenta(Long id, VentaDTO dto) {
        Venta venta = obtenerVenta(id);
        venta.setSucursal(dto.getSucursal());
        venta.setFechaVenta(dto.getFechaVenta());
        venta.setProducto(dto.getProducto());
        venta.setCantidad(dto.getCantidad());
        venta.setPrecioUnitario(dto.getPrecioUnitario());
        return ventaRepository.save(venta);
    }

    @Override
    public void eliminarVenta(Long id) {
        ventaRepository.deleteById(id);
    }
}
